﻿using System;
using TCEngine;

namespace TCGame
{
    public class App
    {
        public static void Main()
        {
            TecnoCampusEngine.Get.Run(new SuperAwesomeGame());
        }
    }
}
